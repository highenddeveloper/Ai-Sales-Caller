<?php
$site_title = 'Xeno - Tech and AI Solution PHP Templatete';
$special_css = 'xeno-ai-agency';
$special_js = 'ai-agency';
$body_class = 'ai-agency';
require_once 'layout/headers/header-five.php';
include 'parts/xeno-ai-agency/xeno-hero.php';
include 'parts/xeno-ai-agency/xeno-company-ai.php';
include 'parts/xeno-ai-agency/xeno-features-ai.php';
include 'parts/xeno-ai-agency/xeno-service-ai.php';
include 'parts/xeno-ai-agency/xeno-features-ai-two.php';
include 'parts/xeno-ai-agency/xeno-features-ai-three.php';
include 'parts/xeno-ai-agency/xeno-ai-business.php';
include 'parts/xeno-ai-agency/xeno-pricing-ai.php';
include 'parts/xeno-ai-agency/xeno-testimonial-ai.php';
include 'parts/xeno-ai-agency/xeno-faq-ai.php';
include 'parts/xeno-ai-agency/xeno-cta-ai.php';
require_once 'layout/footers/xeno-footer-ai.php';



                    
                    



                    
                