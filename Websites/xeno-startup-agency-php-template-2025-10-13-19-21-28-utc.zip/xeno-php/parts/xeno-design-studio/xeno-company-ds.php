<!--======  Start Logos Section  ======-->
<section class="xeno-company-ds pt-130 pb-130">
    <div class="container-fluid">
        <!-- Client Slider -->
        <div class="company-slider">
            <!-- Client Item -->
            <div class="xeno-client-item">
                <div class="client-img">
                    <a href="index-design-studio.php"><img src="assets/images/design-studio/company/company1.png" alt="Company"></a>
                </div>
            </div>
            <!-- Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <a href="index-design-studio.php"><img src="assets/images/design-studio/company/company2.png" alt="Company"></a>
                </div>
            </div>
            <!-- Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <a href="index-design-studio.php"><img src="assets/images/design-studio/company/company3.png" alt="Company"></a>
                </div>
            </div>
            <!-- Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <a href="index-design-studio.php"><img src="assets/images/design-studio/company/company4.png" alt="Company"></a>
                </div>
            </div>
            <!-- Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <a href="index-design-studio.php"><img src="assets/images/design-studio/company/company5.png" alt="Company"></a>
                </div>
            </div>
            <!-- Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <a href="index-design-studio.php"><img src="assets/images/design-studio/company/company6.png" alt="Company"></a>
                </div>
            </div>
            <!-- Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <a href="index-design-studio.php"><img src="assets/images/design-studio/company/company4.png" alt="Company"></a>
                </div>
            </div>
        </div>
    </div>
</section>