<!--=== Post Author Box ===-->
<div class="post-author-box mb-70" data-aos="fade-up" data-aos-duration="1000">
	<div class="author-thumbnail">
		<img src="assets/images/innerpage/blog/author1.jpg" alt="author image">
	</div>
	<div class="author-info">
		<h4 class="title">Nicholas A. Tavera</h4>
		<p>Expanding into new markets attracting more customers requires a well-crafted marketing and sales strategy consulting agency conducts market.</p>
		<ul class="social-link">
			<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
			<li><a href="#"><i class="fab fa-twitter"></i></a></li>
			<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
			<li><a href="#"><i class="fab fa-instagram"></i></a></li>
		</ul>
	</div>
</div>