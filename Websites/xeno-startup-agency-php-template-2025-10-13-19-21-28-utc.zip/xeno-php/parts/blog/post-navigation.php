<!--=== Post Navigation ===-->
<div class="post-navigation mb-40" data-aos="fade-up" data-aos-duration="1200">
	<div class="post-nav-item prev-post mb-40">
		<div class="thumb">
			<img src="assets/images/innerpage/blog/thumb1.jpg" alt="Thumbnail">
		</div>
		<div class="content">
			<a href="#" class="post-date">10 Sep 2024</a>
			<h6><a href="blog-details.php">Leverage Social Media
				Brand Tips business</a></h6>
		</div>
	</div>
	<div class="post-nav-item next-post item-rtl mb-40">
		<div class="thumb">
			<img src="assets/images/innerpage/blog/thumb2.jpg" alt="Thumbnail">
		</div>
		<div class="content">
			<a href="#" class="post-date">10 Sep 2024</a>
			<h6><a href="blog-details.php">Navigating Trends in the Digital Landscape</a></h6>
		</div>
	</div>
</div><!--=== Post Navigation ===-->