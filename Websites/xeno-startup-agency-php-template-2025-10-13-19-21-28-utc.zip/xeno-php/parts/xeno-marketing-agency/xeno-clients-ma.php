<!--====== Start Clients Section ======-->
<section class="xeno-clients-ma pb-100">
    <div class="container">
        <!-- Client Slider -->
        <div class="client-slider">
            <!-- Xeno Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <img src="assets/images/marketing-agency/client/client1.png" alt="Client Image">
                </div>
            </div>
            <!-- Xeno Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <img src="assets/images/marketing-agency/client/client2.png" alt="Client Image">
                </div>
            </div>
            <!-- Xeno Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <img src="assets/images/marketing-agency/client/client3.png" alt="Client Image">
                </div>
            </div>
            <!-- Xeno Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <img src="assets/images/marketing-agency/client/client4.png" alt="Client Image">
                </div>
            </div>
            <!-- Xeno Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <img src="assets/images/marketing-agency/client/client5.png" alt="Client Image">
                </div>
            </div>
            <!-- Xeno Client Item -->
            <div class="xeno-client-item">
                <div class="thumbnail">
                    <img src="assets/images/marketing-agency/client/client3.png" alt="Client Image">
                </div>
            </div>
        </div>
    </div>
</section><!--====== End Clients Section ======-->