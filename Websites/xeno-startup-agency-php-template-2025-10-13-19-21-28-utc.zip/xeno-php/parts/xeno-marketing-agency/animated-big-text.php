<!--=== Animated Big Text ===-->
<div class="animated-big-text">
	<div class="headline-wrap style-one">
		<span class="marquee-wrap">
			<span class="marquee-inner left">
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Video Marketing</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>SEO Marketing</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>SMM Marketing</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Marketing Agency</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Digital Marketing Agency</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Web Design & Development</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Influencer Marketing</span>
			</span>
			<span class="marquee-inner left">
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Video Marketing</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>SEO Marketing</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>SMM Marketing</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Marketing Agency</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Digital Marketing Agency</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Web Design & Development</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Influencer Marketing</span>
			</span>
			<span class="marquee-inner left">
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Video Marketing</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>SEO Marketing</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>SMM Marketing</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Marketing Agency</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Digital Marketing Agency</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Web Design & Development</span>
				<span class="marquee-item"><i class="flaticon-asterisk"></i>Influencer Marketing</span>
			</span>
		</span>
	</div>
</div>