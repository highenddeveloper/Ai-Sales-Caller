<?php
$site_title = 'Xeno - Marketing Agency PHP Templatete';
$special_css = 'xeno-marketing-agency';
$special_js = 'marketing-agency';
$body_class = 'marketing-agency';
require_once 'layout/headers/header-four.php';
include 'parts/xeno-marketing-agency/xeno-hero.php';
include 'parts/xeno-marketing-agency/animated-big-text.php';
include 'parts/xeno-marketing-agency/xeno-work-process-ma.php';
include 'parts/xeno-marketing-agency/xeno-about-ma.php';
include 'parts/xeno-marketing-agency/xeno-services-ma.php';
include 'parts/xeno-marketing-agency/xeno-choose-ma.php';
include 'parts/xeno-marketing-agency/xeno-project-ma.php';
include 'parts/xeno-marketing-agency/xeno-team-ma.php';
include 'parts/xeno-marketing-agency/animated-big-text.php';
include 'parts/xeno-marketing-agency/xeno-faq-ma.php';
include 'parts/xeno-marketing-agency/xeno-testimonial-ma.php';
include 'parts/xeno-marketing-agency/xeno-blog-ma.php';
include 'parts/xeno-marketing-agency/xeno-clients-ma.php';
require_once 'layout/footers/xeno-footer-ma.php';



                    
                